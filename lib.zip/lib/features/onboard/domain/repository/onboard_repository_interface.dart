import 'package:sixam_mart/interfaces/repository_interface.dart';

abstract class OnboardRepositoryInterface extends RepositoryInterface {

}